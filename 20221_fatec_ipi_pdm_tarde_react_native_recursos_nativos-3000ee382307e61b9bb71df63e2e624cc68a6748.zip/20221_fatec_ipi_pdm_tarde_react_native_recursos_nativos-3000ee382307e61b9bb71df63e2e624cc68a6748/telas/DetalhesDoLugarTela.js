import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const DetalhesDoLugarTela = () => {
  return (
    <View>
      <Text>DetalhesDoLugarTela</Text>
    </View>
  )
}

export default DetalhesDoLugarTela

const styles = StyleSheet.create({})


import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const NovoLugarTela = () => {
  return (
    <View>
      <Text>NovoLugarTela</Text>
    </View>
  )
}

export default NovoLugarTela

const styles = StyleSheet.create({})
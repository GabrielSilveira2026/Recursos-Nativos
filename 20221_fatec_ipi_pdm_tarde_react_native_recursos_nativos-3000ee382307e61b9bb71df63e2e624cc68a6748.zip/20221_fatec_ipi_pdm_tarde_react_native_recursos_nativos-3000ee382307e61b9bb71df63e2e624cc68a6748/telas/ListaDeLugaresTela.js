import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ListaDeLugaresTela = () => {
  return (
    <View>
      <Text>ListaDeLugaresTela</Text>
    </View>
  )
}

export default ListaDeLugaresTela

const styles = StyleSheet.create({})
import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const MapaTela = () => {
  return (
    <View>
      <Text>MapaTela</Text>
    </View>
  )
}

export default MapaTela

const styles = StyleSheet.create({})
import { StyleSheet, Text, View } from 'react-native';

import container from './navegacao/LugaresNavigator'

export default function App() {
  return container
}

export default {
    primary: '#FC9208'
}